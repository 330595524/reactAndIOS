//1，立执行函数封装
(function(windows,undefined){
   function jquery(){
   	 //return new jquery();
   	 return new jquery.init();
   }
   jquery.prototype={
   	init:function(){
   
   	}
   }
   jquery.extend=function(){
   	//合理的操作aruguments
   	//赋予默认值,防止错误使用
     var target=arguments[0]||{};
     var length=arguments.length;
     var i=1;
     var options;
     if(target!=='object'){
     	target={};
     }
     if(length===1){
     	target=this;
     	i--;
     };
     for(;i<length;i++){
        if((options=arguments[i])!=null){
         for(var name in options){
         	target[name]=options[name];
         }
        }
     }
   }
   jquery.extend({
   	// css模块
   })
   jquery.extend({
   	// 动画模块
   })   
   jquery.prototype=jquery.prototype.init.prototype=jquery.fn;
   window.$=jquery;
   window.jquery=jquery;
	if ( typeof define === "function" && define.amd && define.amd.jQuery ) {
		define( "jquery", [], function () { return jQuery; } );
	}   
})(window);