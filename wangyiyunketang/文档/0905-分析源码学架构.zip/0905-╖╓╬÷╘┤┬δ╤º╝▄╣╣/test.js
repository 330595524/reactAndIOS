const myex=require('./myexpress');
const app=myex();
app.listen(3000);
console.log(app);