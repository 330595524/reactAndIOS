const express = require('express')
const app = express()
app.set('view engine',)

app.listen('/app',(req,res) => {
	res.send()
})
