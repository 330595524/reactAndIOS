import React, {Component} from 'react'

class HashHistory extends Component {
	render() {
		return <div>HashHistory</div>
	}
}

export default HashHistory
