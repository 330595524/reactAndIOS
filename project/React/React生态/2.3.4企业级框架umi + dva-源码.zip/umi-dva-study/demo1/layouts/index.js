import React from 'react'
const App = (props) => (
	<div>
		title
		{props.children}
	</div>
)

export default App
