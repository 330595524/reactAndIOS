
import styles from './user.css';

export default function() {
	return (
		<div className={styles.normal}>
			<h1>Page user b</h1>
		</div>
	);
}
