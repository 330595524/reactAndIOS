export default {
	"/api/get": ['1',2,3]
}
