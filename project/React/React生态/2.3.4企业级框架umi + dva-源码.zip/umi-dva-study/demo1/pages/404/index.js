
export default function() {
	return (
		<div >
			<h1>Page 404</h1>
		</div>
	);
}
