import React from 'react'
const App = (props) => (
	<div>
		index
	</div>
)

export default App
