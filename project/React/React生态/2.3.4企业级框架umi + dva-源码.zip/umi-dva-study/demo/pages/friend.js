
import styles from './friend.css';

export default function() {
  return (
    <div className={styles.normal}>
      <h1>Page friend dsdsds</h1>
    </div>
  );
}
