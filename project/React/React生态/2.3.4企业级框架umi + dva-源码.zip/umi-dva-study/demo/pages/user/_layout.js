
import React from 'react'
export default function(props) {
	return (
		<div >
			<p>module user</p>
			{props.children}
		</div>
	);
}
