import React from 'react'
export default function(props) {
	return (
		<div >
			user a
		</div>
	);
}
