import React from 'react'
export default function(props) {
	return (
		<div >
			user b
		</div>
	);
}
