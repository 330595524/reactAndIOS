console.log('hello 1')
require('./demo.js')
