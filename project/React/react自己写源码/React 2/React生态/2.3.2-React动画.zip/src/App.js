import React from 'react';
import logo from './logo.svg';
import App from './ani2/demo1'
import './index.css';



export default App;
