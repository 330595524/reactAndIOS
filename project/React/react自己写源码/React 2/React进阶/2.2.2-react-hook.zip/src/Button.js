import React,{Component} from 'react'
import './font-demo/iconfont.css'
class Button extends Component{
	render() {
		return (
			<div>

				<button>
					<span className="icon iconfont icon-jujia-beiru"></span>
					dsdsds
				</button>
			</div>
		);
	}
}

export default Button
