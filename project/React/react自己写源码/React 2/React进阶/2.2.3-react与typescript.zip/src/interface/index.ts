export interface StudentItem {
  name: string,
  age: number,
}
