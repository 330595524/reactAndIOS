export interface FriendItem {
  name: string,
  age: number,
  id: number
}
