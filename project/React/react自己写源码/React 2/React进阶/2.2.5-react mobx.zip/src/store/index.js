import friend from './friend'
import post from './post'


export default {
	friend,
	post
}
