import { combineReducers } from 'redux'
import title from './title'
import friend from './friend'
export default combineReducers({
  title,
  friend
  // friend,
  // post
})
