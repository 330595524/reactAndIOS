# lesson9

### Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run start
```

### Compiles and minifies for production
```
npm run build
```

### Visualize size of webpack output files with an interactive zoomable treemap
```
npm run analyz
```